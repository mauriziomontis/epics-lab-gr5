/* Generated file, do not edit! */

/* Version determined from build date/time */

#ifndef group5VERSION
  #define group5VERSION "2024-08-14T16:11+0200"
#endif
#ifndef group5VERSION_DATE
  #define group5VERSION_DATE "build date/time: "
#endif
